package com.example.week7;

public class QuestionAnswer {
    public static String question[] ={
            "Who is the best lecturer?",
            "Which one is not the programming language?",
            "Where you are watching this video?",
            "Which company owns the Apple?"
    };
    public static String choices[][] = {
            {"Haritha","Sandeep","Shareef","NaGARAJU"},
            {"Java","Kotlin","Notepad","Python"},
            {"Facebook","Whatsapp","Instagram","Youtube"},
            {"Google","Apple","Nokia","Samsung"}
    };
    public static String correctAnswers[] = {
            "Haritha",
            "Notepad",
            "Youtube",
            "Apple"
    };
}