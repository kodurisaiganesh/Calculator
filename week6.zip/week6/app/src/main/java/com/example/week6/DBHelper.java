package com.example.week6;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "mycontactlist";
    public static final String COL_1 = "Name";
    public static final String COL_2 = "PhoneNo";

    public DBHelper(Context context) {
        super(context, "mycontactslist.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Correct SQL statement with spaces
        String createTable = "CREATE TABLE " + TABLE_NAME + " (" +
                COL_1 + " TEXT, " +
                COL_2 + " TEXT)";
        sqLiteDatabase.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        // Correct SQL statement with spaces
        String dropTable = "DROP TABLE IF EXISTS " + TABLE_NAME;
        sqLiteDatabase.execSQL(dropTable);
        onCreate(sqLiteDatabase);
    }

    public void insertData(String name, String phoneNo) {
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues cvalues = new ContentValues();
        cvalues.put(COL_1, name);
        cvalues.put(COL_2, phoneNo);
        mydb.insert(TABLE_NAME, null, cvalues);
        // Close the database after insert operation
        mydb.close();
    }
}
